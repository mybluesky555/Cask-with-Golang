# golang_api
Please refer to the newest repository instead, here:  
```
https://github.com/ydhnwb/golang_heroku
```
